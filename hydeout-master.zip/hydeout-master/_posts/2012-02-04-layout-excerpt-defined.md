---
title: "Layout: Excerpt (Defined)"
layout: post
excerpt: "This is a user-defined post excerpt. It should be displayed in place of the auto-generated excerpt or post content on index pages."
categories:
  - Layout
tags:
  - content
  - excerpt
  - layout
last_modified_at: 2012-02-04T12:43:31-05:00
---

This is the start of the post content.

This paragraph should be absent from an index page where `post.excerpt` is shown.